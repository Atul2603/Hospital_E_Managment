<div class="row" id="section">
	<div class="col-md-2" id="sidebar">
		<nav class="navbar">
		<div class="container-fluid">
		<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span> 
		</button>
		
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
		<li class="active"><a href="dashboard.php" class="fa fa-list"> Dashboard</a></li>
		<li><a href="new_reg.php" class="fa fa-plus"> New Reg</a></li>
		<li><a href="all_reg.php" class="fa fa-list-alt"> All Reg</a></li>
		<li><a href="add_doctor.php" class="fa fa-user-md"> Add Doctor</a></li> 
		<li><a href="all_doctor.php" class="fa fa-list">All Doctor</a></li> 
		<li><a href="../index.php" class="fa fa-lock"> Logout</a></li> 
		</ul>
		
		</div>
		</div>
		</nav>
       	</div>