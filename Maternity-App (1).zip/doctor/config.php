<?php 
$con = mysqli_connect('localhost','root','','hospital');
?>