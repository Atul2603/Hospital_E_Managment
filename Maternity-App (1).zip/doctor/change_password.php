<?php include('header.php'); ?>
      <!-- End of Header -->
      <?php include('sidebar.php'); ?>
       	<div class="col-md-10" id="righ_section">
       		
       		<div class="panel">
       			<div class="panel-heading">
       				<h3>Change Password</h3>
       			</div>
       			<div class="panel-body">
       			
       			 <div class="col-md-6">
       			 	<div class="form-group">
       			 		<label for="">Current Password</label>
       			 		<input type="password" name="cpass" id="" class="form-control">
       			 	</div>
       			 	<div class="form-group">
       			 		<label for="">New Password</label>
       			 		<input type="password" name="npass" id="" class="form-control">
       			 	</div>
       			 	<div class="form-group">
       			 		<label for="">Confirm Password</label>
       			 		<input type="password" name="conpass" id="" class="form-control">
       			 	</div>
       			 	<div class="form-group">
       			 		<input type="submit" name="" value="Change Password" id="" class="btn btn-success">
       			 	</div>
       			 </div>
       				
       			</div>
       		</div>
       		
       		
       		
       	</div>
<?php include('footer.php'); ?>       