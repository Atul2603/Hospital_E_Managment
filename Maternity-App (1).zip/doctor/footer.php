</div><!-- End of Section -->	
    	
    	
    </div><!-- End of Container Fluid -->
    	
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>