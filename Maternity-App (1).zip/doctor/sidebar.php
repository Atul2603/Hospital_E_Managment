 <div class="row" id="section">
       	<div class="col-md-2" id="sidebar">
		<nav class="navbar">
		<div class="container-fluid">
		<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span> 
		</button>
		
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
		<li class="active"><a href="dashboard.php">Dashboard</a></li>
		<li><a href="enquiry.php">Enquiry</a></li>
		<li><a href="done.php">Enquiry Done</a></li> 
		<li><a href="find_patient.php">Find Patient Report</a></li> 
		<li><a href="change_password.php">Change Password</a></li>
		<li><a href="../index.php">Logout</a></li> 
		</ul>
		
		</div>
		</div>
		</nav>
       	</div>