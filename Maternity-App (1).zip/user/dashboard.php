<?php include('header.php'); ?>
      <!-- End of Header -->
      <?php include('sidebar.php'); ?>
       	<div class="col-md-10" id="righ_section">
       		
       		<div class="panel">
       			<div class="panel-heading">
       				<h3>Dashboard</h3>
       			</div>
       			<div class="panel-body text-center">
       			
       			  <div class="col-md-3">
       			  	<i class="fa fa-user fa-3x"></i><br />
       			  	<a href="profile.php">Profile</a>
       			  </div>
       			  <div class="col-md-3">
       			  		<i class="fa fa-calendar fa-3x"></i><br />
       			  	<a href="routine.php">Weekly Test Report</a>
       			  </div>
       			  <div class="col-md-3">
       			  	<i class="fa fa-lock fa-3x"></i><br />
       			  	<a href="change_password.php">Change Password</a>
       			  </div>
       			  <div class="col-md-3">
       			  	
       			  </div>
       				
       			</div>
       		</div>
       		
       		
       		
       	</div>
<?php include('footer.php'); ?>       